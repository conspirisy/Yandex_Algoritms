package Sprint_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
* ID успешной посылки = 70464148
* */
public class FinalBLuckyHands {
    public static void main(String[] args) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            int pushAbility = Integer.parseInt(reader.readLine()) * 2;
            int[] countDigit = new int[9];
            for (int i = 0; i < 4; i++) {
                for (char c : reader.readLine().toCharArray()) {
                    if (c != '.') {
                        countDigit[Integer.parseInt(String.valueOf(c)) - 1]++;
                    }
                }
            }
            int result = 0;
            for (int i : countDigit) {
                if (i > 0 && pushAbility >= i) result++;
            }
            System.out.println(result);
        }
    }
}
